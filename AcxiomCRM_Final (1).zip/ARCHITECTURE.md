# AcxiomCRM Architecture

The project uses a layered MVC structure:

- **Presentation:** Razor views under `Views/`, Bootstrap styling and Chart.js dashboard visualizations.
- **Application/workflow:** MVC controllers under `Controllers/` validate requests and coordinate persistence.
- **Domain:** CRM entities under `Models/` define the fields and data-annotation validation rules.
- **Data access:** `Data/ApplicationDbContext.cs` maps entities through Entity Framework Core.
- **Database:** SQLite database file (`acxiomcrm.db`) is created locally at first run and is excluded from Git.
- **Security:** ASP.NET Core Identity, role-based `[Authorize]` attributes, antiforgery validation for MVC forms, password policy and lockout configuration.
- **Cross-cutting services:** `Services/AuditService.cs` records supported create/update/delete and administration events.

```text
Browser / API Client
        |
        v
Razor Views / REST Controllers
        |
        v
MVC Controllers + Validation + Authorization
        |
        v
Entity Framework Core (ApplicationDbContext)
        |
        v
SQLite Database

Identity + Role Authorization + Audit Logging apply across the application.
```
