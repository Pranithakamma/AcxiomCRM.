using System.Text.Json;
using AcxiomCRM.Data;
using AcxiomCRM.Models;
using Microsoft.AspNetCore.Http;

namespace AcxiomCRM.Services;
public class AuditService
{
    private readonly ApplicationDbContext _db;
    private readonly IHttpContextAccessor _http;
    public AuditService(ApplicationDbContext db, IHttpContextAccessor http) { _db = db; _http = http; }
    public async Task RecordAsync(string action, string entity, string id, object? oldValue = null, object? newValue = null)
    {
        var context = _http.HttpContext;
        _db.AuditLogs.Add(new AuditLog {
            UserId = context?.User?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value,
            Action = action, EntityName = entity, RecordId = id,
            OldValue = oldValue == null ? null : JsonSerializer.Serialize(oldValue),
            NewValue = newValue == null ? null : JsonSerializer.Serialize(newValue),
            IPAddress = context?.Connection.RemoteIpAddress?.ToString(),
            CreatedDate = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();
    }
}
