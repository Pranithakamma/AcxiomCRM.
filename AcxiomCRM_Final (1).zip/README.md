# AcxiomCRM — CRM Management System

ASP.NET Core MVC CRM assignment implementation using C#, ASP.NET Core Identity, Entity Framework Core and SQLite. The UI uses Bootstrap and Chart.js via CDN.

## Included modules

- Authentication using ASP.NET Core Identity, hashed passwords, password policy, and lockout after repeated failed attempts.
- Roles: `Admin`, `Manager`, `SalesExecutive`.
- Dashboard KPIs and lead/opportunity charts.
- Customer CRUD, search, validation, duplicate email/phone checks, status, assignment field and notes.
- Lead CRUD, search, source, status, priority, assignment field and notes.
- Opportunity CRUD, stage, amount, probability, expected close date, customer/owner/source/notes fields and weighted pipeline calculation.
- Follow-up creation/listing, planned-date validation and completion flag.
- Activity tracking.
- Audit logging for supported CRM changes, with user/timestamp/IP and before/after data; filtered audit log page.
- Admin-only user creation, role assignment and account lockout/activation.
- Admin/Manager reports for customers, leads, opportunities, follow-ups and audit events, with CSV exports.
- Authenticated REST endpoints: `GET/POST /api/customers`, `GET/POST /api/leads`, `GET/POST /api/opportunities`.

## Requirements

- .NET 10 SDK
- Internet connection for NuGet restore and Bootstrap/Chart.js CDN assets
- Visual Studio with ASP.NET and web development workload, or terminal

## Run locally

1. Extract the repository ZIP.
2. Open `AcxiomCRM.csproj` in Visual Studio, or open a terminal in this folder.
3. Run:
   ```bash
   dotnet restore
   dotnet build
   dotnet run
   ```
4. Open the local URL printed in the terminal.
5. Register the first account using the Register link, then sign in.
6. Open **Initial Setup** in the navigation and type `CLAIM ADMIN` to give the first account the Admin role. This endpoint is available only when no Admin exists.
7. Create test accounts from **Users** and assign roles. Use temporary passwords that meet the configured policy.

**Security note:** `SetupController` is a first-run convenience for this assignment. After claiming the first Admin account, remove `Controllers/SetupController.cs` and `Views/Setup/` before production deployment. Do not publish real credentials or the SQLite database.

## API notes

The API endpoints require an authenticated request. Customer endpoints use a DTO and return appropriate success/not-found/conflict/validation responses. The endpoints are intended as an assignment baseline; configure a proper API authentication scheme (for example, bearer tokens) before using them outside a local demo.

Example customer request body:

```json
{
  "name": "Asha Rao",
  "email": "asha@example.com",
  "phone": "9876543210",
  "company": "Example Ltd",
  "address": "Bengaluru",
  "status": "Active",
  "notes": "Follow up next week"
}
```

## Suggested test checklist

- Register, sign in and sign out.
- Try a weak password and confirm the password policy is enforced.
- Enter an incorrect password repeatedly and check lockout behavior.
- Claim Admin once, then confirm the setup action is denied after an Admin exists.
- As Admin, create a Manager and SalesExecutive account and verify role display and deactivate/activate controls.
- As SalesExecutive, confirm User Management, Reports and Audit Log are not accessible.
- Create/edit/search customers; test invalid email, invalid phone and duplicate email/phone.
- Create leads and test allowed status values.
- Create opportunities with zero/negative amount, probability outside 0–100, and past close date for active stages.
- Create a planned follow-up in the past and verify validation.
- Check dashboard totals, reports, CSV exports and audit entries.
- Test API requests with missing authentication and valid authenticated requests.

## Limitations to verify before final submission

This project has been assembled from the written assignment requirements but **has not been compiled or run in this environment**, because the .NET SDK is unavailable here. Run `dotnet restore` and `dotnet build` on your machine before submitting and fix any environment-specific issues. Some advanced requirements (for example, full lead-to-customer/opportunity conversion workflow, custom API token authentication, audit events for every authentication outcome, and pagination/date-range filters across every report) are not fully implemented and should not be described as complete unless you add and test them.
