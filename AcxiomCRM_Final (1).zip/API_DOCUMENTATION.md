# REST API Quick Reference

All endpoints require an authenticated request. This assignment baseline uses the application's Identity cookie authentication; it is not yet configured as a public bearer-token API.

## Customers

- `GET /api/customers` — list customers.
- `GET /api/customers/{id}` — fetch one customer; returns 404 if absent.
- `POST /api/customers` — create customer; returns 201, 400 for validation errors, or 409 for duplicate email/phone.

Example POST body:

```json
{
  "name": "Asha Rao",
  "email": "asha@example.com",
  "phone": "9876543210",
  "company": "Example Ltd",
  "address": "Bengaluru",
  "status": "Active",
  "notes": "Follow up next week"
}
```

## Leads

- `GET /api/leads`
- `GET /api/leads/{id}`
- `POST /api/leads` — validates model fields and lead status.

## Opportunities

- `GET /api/opportunities`
- `GET /api/opportunities/{id}`
- `POST /api/opportunities` — validates positive amount, probability from 0–100 and active-opportunity close date; returns weighted amount in response.

## Error responses

The API uses standard HTTP responses such as 200, 201, 400, 401, 403, 404 and 409 where applicable. For production use, configure bearer-token authentication, DTOs for every resource, and consistent centralized error responses.
